import React, { useCallback, useEffect, useRef, useState } from 'react'
import { EmblaOptionsType, EmblaCarouselType, EmblaEventType } from 'embla-carousel'
import useEmblaCarousel from 'embla-carousel-react'
import Autoplay from 'embla-carousel-autoplay'
import {
  NextButton,
  PrevButton,
  usePrevNextButtons
} from './EmblaCarouselArrowButtons'
import Image from 'next/image'
import Link from 'next/link'
import { NewMedia } from '../../api/Api'
import dynamic from 'next/dynamic'
import ClassNames from 'embla-carousel-class-names'
import { DotButton, useDotButton } from './EmblaCarouselDotButton'
import { root } from 'postcss'
const CountDown = dynamic(() => import('../CountDown'), { ssr: false })

type PropType = {
  slides: any
  lang: any
  options?: EmblaOptionsType
  timerNeed: any
}

const EmblaCarousel: React.FC<PropType> = (props: any) => {
  const { slides, options } = props
  const [emblaRef, emblaApi] = useEmblaCarousel(options, [Autoplay({ playOnInit: true, delay: 3000 })])
  const [isPlaying, setIsPlaying] = useState<boolean>(false)

  const { selectedIndex, scrollSnaps, onDotButtonClick } = useDotButton(emblaApi)

  var {
    prevBtnDisabled,
    nextBtnDisabled,
    onPrevButtonClick,
    onNextButtonClick
  } = usePrevNextButtons(emblaApi)

  const onButtonAutoplayClick = useCallback(
    (callback: () => void) => {
      const autoplay: any = emblaApi?.plugins()?.autoplay
      if (!autoplay) return

      const resetOrStop: any =
        autoplay.options.stopOnInteraction === false
          ? autoplay.reset
          : autoplay.stop

      resetOrStop()
      callback()
    },
    [emblaApi]
  )

  const toggleAutoplay = useCallback(() => {
    const autoplay: any = emblaApi?.plugins()?.autoplay
    if (!autoplay) return

    const playOrStop: any = autoplay.isPlaying() ? autoplay.stop : autoplay.play
    playOrStop()
  }, [emblaApi])

  useEffect(() => {
    const autoplay: any = emblaApi?.plugins()?.autoplay
    if (!autoplay) return

    setIsPlaying(autoplay.isPlaying())
  }, [emblaApi])

  const origin =
    typeof window !== 'undefined' && window.location.origin
      ? window.location.origin
      : '';

  return (
    <>
      <div className={`relative container ${slides?.length === 1 ? "emblaSingleSlide" : "embla"}`}>
        <div className="embla__viewport" ref={emblaRef}>
          <div className="embla__container">
            {slides?.map((item: any, i: number) => (
              item?.featured_image_app ? (
                <div className="embla__slide embla__class-names relative" key={i}>
                  <Link
                    href={`${origin}/${props?.lang}/${item?.redirection_type == 0 ? `brand/${item?.brand?.slug}` : item?.redirection_type == 2 ? `product/${item?.pro?.slug}` : item?.redirection_type == 3 ? `category/${item?.cat?.slug}` : item?.redirection_type == 4 ? `${item?.custom_link}` : null}`}
                  >
                    <Image
                      src={item?.featured_image_app ? NewMedia + item?.featured_image_app?.image : 'https://partners.tamkeenstores.com.sa/public/assets/new-media/3f4a05b645bdf91af2a0d9598e9526181714129744.png'}
                      alt={`${props?.lang == 'ar' ? item?.alt_ar : item?.alt}-${i + 12}`}
                      title={props?.lang == 'ar' ? item?.name_ar : item?.name}
                      height={0}
                      width={0}
                      sizes="(min-width: 808px) 50vw, 100vw"
                      className='w-full h-auto rounded-lg embla__slide__img'
                      quality={100}
                      priority
                    />
                  </Link>
                  {item?.timer ?
                    <CountDown lang={props?.lang} timer={item?.timer} timerNeed={props?.timerNeed} />
                    : null}
                </div>
              ) : null
            ))}
          </div>
        </div>
      </div>
    </>
  )
}

export default EmblaCarousel